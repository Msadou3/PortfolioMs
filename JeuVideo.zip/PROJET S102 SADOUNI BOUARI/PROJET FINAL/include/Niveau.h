#ifndef NIVEAU_H_INCLUDED
#define NIVEAU_H_INCLUDED

#include <string>
#include <vector>
#include <iostream>
#include "Objet.h"


class Niveau{
 private:
     vector<Objet> _lesObjets;
     int _lesPieces;

 public:
    Niveau (Image&, const string&, Dictionnaire& );

    int getPieces()const{return _lesPieces;}
    void dessiner();
    bool caseEstLibre(int,int);
    void testerBonusEtPrendre(int,int);
    void cache(Objet&);
    int indiceObjet(int,int,const string&);
};


#endif // NIVEAU_H_INCLUDED
