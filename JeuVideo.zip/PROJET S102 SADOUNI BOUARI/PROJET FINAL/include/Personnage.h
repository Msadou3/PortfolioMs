#ifndef PERSONNAGE
#define PERSONNAGE

#include "Niveau.h"
#include "Image.h"
#include <string>
#include <vector>
using namespace std;

enum direction {
    BAS,
    GAUCHE,
    DROIT,
    HAUT
};

class Personnage {
private:
    Image _apparence;
    int _positionX;
    int _positionY;
    int _spriteX;
    int _spriteY;
    direction _orientation;
    int _etatAnimation;

public:
    Personnage();
    Personnage(Image&, int, int, int, int, direction);

    int getPositionX() const { return _positionX; }
    int getPositionY() const { return _positionY; }

    void afficher() const;
    void seDeplacerDroite(Niveau&);
    void seDeplacerGauche(Niveau&);
    void seDeplacerBas(Niveau&);
    void seDeplacerHaut(Niveau&);

    void changerApparence();

    void seDeplacerAleatoirement(Niveau&);

    bool limiteAtteinte(direction, Niveau&) const;

    bool estEnCollisionAvec(const Personnage&) const;

    void mettreAJourAnimation();
};

#endif // PERSONNAGE
