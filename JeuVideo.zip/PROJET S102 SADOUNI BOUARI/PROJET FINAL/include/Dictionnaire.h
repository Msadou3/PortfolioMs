#ifndef DICTIONNAIRE_H_INCLUDED
#define DICTIONNAIRE_H_INCLUDED
#include <string>
#include <vector>
#include <iostream>
#include "Tuile.h"


using namespace std;

class Dictionnaire {
 private:
     vector<Tuile> _lesTuiles;

 public:

    Dictionnaire(const string&);

    void afficher()const;

    bool recherche(const string&, Tuile&) ;
};


#endif // DICTIONNAIRE_H_INCLUDED
