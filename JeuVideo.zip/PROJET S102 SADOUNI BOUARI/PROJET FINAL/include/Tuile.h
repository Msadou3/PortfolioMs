#ifndef TUILE_H_INCLUDED
#define TUILE_H_INCLUDED
#include <string>
#include <vector>
#include <iostream>

using namespace std;


class Tuile {

 private:

     string _nom;
     int _posX;
     int _posY;
     string _propriete;

 public:

    Tuile (const string&, int, int, const string& );
    Tuile();

    string getNom(){return _nom;}
    int getX(){return _posX;}
    int getY(){return _posY;}
    string getProp(){return _propriete;}

    void afficher()const ;

};


#endif // TUILE_H_INCLUDED
