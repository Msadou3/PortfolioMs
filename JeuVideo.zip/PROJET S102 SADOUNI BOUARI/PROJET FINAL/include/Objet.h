#ifndef OBJET_H_INCLUDED
#define OBJET_H_INCLUDED

#include <string>
#include <vector>
#include <iostream>
#include "Image.h"
#include "Dictionnaire.h"

using namespace std;

class Objet {
 private:
     Image _imageO;
     int _posXO;
     int _posYO;
     string _proprieteO;

 public:
     Objet (Image&, string&, Dictionnaire&, int, int);

     int getPosXO(){return _posXO;}
     int getPosYO(){return _posYO;}
     string getPropriete(){return _proprieteO;}
     void modifPropriete(const string&s){_proprieteO=s;}
     void dessiner();
};

#endif // OBJET_H_INCLUDED
