/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-2.30.8 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-2.30.8"
#endif
