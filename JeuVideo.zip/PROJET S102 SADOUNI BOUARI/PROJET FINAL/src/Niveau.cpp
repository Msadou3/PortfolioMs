#include "Niveau.h"
#include <fstream>



Niveau::Niveau(Image& img, const string& nomFic, Dictionnaire& dico){
    ifstream entree;

    try {
        entree.open(nomFic);
        if(!(entree.is_open())) throw(nomFic);
        int nbTuile;
        if (!entree.eof())
            entree >> nbTuile;
        for (int i = 0; i < nbTuile && !entree.eof(); i++) {
            string nom;
            int x;
            int y;

            entree >> nom;
            entree >> x;
            entree >> y;
            _lesObjets.push_back(Objet(img, nom, dico, x, y));
        }
        entree.close();
    } catch (const string & s) {
        cerr<< "pb ouverture du fichier : " << s;
    }

    _lesPieces=0;
    for(int i=0;i<_lesObjets.size();i++){
        if(_lesObjets[i].getPropriete()=="bonus"){
            _lesPieces+=1;
        }
    }
    cout<<"il y a "<<_lesPieces<<" bonus"<<endl;
}

void Niveau::dessiner(){
    for(int i=0; i<_lesObjets.size(); i++){
        if(_lesObjets[i].getPropriete()!="cache"){
            _lesObjets[i].dessiner();
        }

    }
}


bool Niveau::caseEstLibre(int x,int y){
    int indice=indiceObjet(x,y,"solide");
    return indice==-1;
    /*
    for(int i=0;i<_lesObjets.size();i++){
        if(_lesObjets[i].getPropriete()=="solide"){
            if(_lesObjets[i].getPosXO()*TAILLE_CASE==x && _lesObjets[i].getPosYO()*TAILLE_CASE==y){
                return false;
            }
        }
    }
    return true;
    */
}



void Niveau::testerBonusEtPrendre(int x,int y){

    int indice=indiceObjet(x,y,"bonus");
    if(indice!=-1){
        _lesPieces--;
        cache(_lesObjets[indice]);
    }
    /*
    for(int i=0;i<_lesObjets.size();i++){
         if(_lesObjets[i].getPropriete()=="bonus"){
            if(_lesObjets[i].getPosXO()*TAILLE_CASE==x && _lesObjets[i].getPosYO()*TAILLE_CASE==y){
                _lesPieces--;
                cache(_lesObjets[i]);
            }
        }
    }
    */
}

void Niveau::cache(Objet&o){
    o.modifPropriete("cache");
}


int Niveau::indiceObjet(int x,int y,const string&prop){
     for(int i=0;i<_lesObjets.size();i++){
         if(_lesObjets[i].getPropriete()==prop){
            if(_lesObjets[i].getPosXO()*TAILLE_CASE==x && _lesObjets[i].getPosYO()*TAILLE_CASE==y){
                return i;
            }
        }
    }
    return -1;
}
