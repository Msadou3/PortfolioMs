#include "Objet.h"

Objet::Objet(Image& image, string& nom, Dictionnaire& dico, int x, int y){
    Tuile t;
    bool existe = dico.recherche(nom, t);
    if (existe){
        image.selectionnerRectangle(t.getX()*TAILLE_CASE, t.getY()*TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
        _imageO = image;
        _proprieteO = t.getProp();
        _posXO = x;
        _posYO = y;
    }
}

void Objet::dessiner(){
    _imageO.dessiner(_posXO*TAILLE_CASE,_posYO*TAILLE_CASE);
}
