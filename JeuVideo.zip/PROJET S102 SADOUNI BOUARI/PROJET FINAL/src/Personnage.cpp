#include "Personnage.h"
#include "Image.h"
#include <string>
#include <vector>
using namespace std;

Personnage::Personnage()
    : _positionX(0), _positionY(0), _spriteX(4), _spriteY(0), _orientation(BAS), _etatAnimation(0) {}

Personnage::Personnage(Image& apparence, int positionX, int positionY, int spriteX, int spriteY, direction orientation)
    : _apparence(apparence), _positionX(positionX), _positionY(positionY), _spriteX(spriteX), _spriteY(spriteY), _orientation(orientation), _etatAnimation(0) {
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
    cout << "Le personnage a �t� cr��" << endl;
}

void Personnage::afficher() const {
    _apparence.dessiner(_positionX, _positionY);
}

void Personnage::seDeplacerDroite(Niveau& niveau) {
    _orientation = DROIT;
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
    if (limiteAtteinte(DROIT, niveau)) {
        _positionX += TAILLE_CASE;
        niveau.testerBonusEtPrendre(_positionX, _positionY);
    }
}

void Personnage::seDeplacerGauche(Niveau& niveau) {
    _orientation = GAUCHE;
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
    if (limiteAtteinte(GAUCHE, niveau)) {
        _positionX -= TAILLE_CASE;
        niveau.testerBonusEtPrendre(_positionX, _positionY);
    }
}

void Personnage::seDeplacerBas(Niveau& niveau) {
    _orientation = BAS;
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, _spriteY * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
    if (limiteAtteinte(BAS, niveau)) {
        _positionY += TAILLE_CASE;
        niveau.testerBonusEtPrendre(_positionX, _positionY);
    }
}

void Personnage::seDeplacerHaut(Niveau& niveau) {
    _orientation = HAUT;
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
    if (limiteAtteinte(HAUT, niveau)) {
        _positionY -= TAILLE_CASE;
        niveau.testerBonusEtPrendre(_positionX, _positionY);
    }
}

void Personnage::changerApparence() {
    if (_spriteX == 7) {
        _spriteX = 1;
    } else {
        _spriteX += 3;
    }
    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
}

void Personnage::seDeplacerAleatoirement(Niveau& niveau) {
    int directionAleatoire = rand() % 4;

    switch (directionAleatoire) {
    case 0:
        if (limiteAtteinte(DROIT, niveau)) {
            _orientation = DROIT;
            _positionX += TAILLE_CASE;
        }
        break;
    case 1:
        if (limiteAtteinte(GAUCHE, niveau)) {
            _orientation = GAUCHE;
            _positionX -= TAILLE_CASE;
        }
        break;
    case 2:
        if (limiteAtteinte(BAS, niveau)) {
            _orientation = BAS;
            _positionY += TAILLE_CASE;
        }
        break;
    case 3:
        if (limiteAtteinte(HAUT, niveau)) {
            _orientation = HAUT;
            _positionY -= TAILLE_CASE;
        }
        break;
    }

    _apparence.selectionnerRectangle(_spriteX * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
}

bool Personnage::limiteAtteinte(direction d, Niveau& niveau) const {
    switch (d) {
    case DROIT:
        return niveau.caseEstLibre(_positionX + TAILLE_CASE, _positionY);
    case GAUCHE:
        return niveau.caseEstLibre(_positionX - TAILLE_CASE, _positionY);
    case BAS:
        return niveau.caseEstLibre(_positionX, _positionY + TAILLE_CASE);
    case HAUT:
        return niveau.caseEstLibre(_positionX, _positionY - TAILLE_CASE);
    }
    return false;
}

bool Personnage::estEnCollisionAvec(const Personnage& autre) const {
    return (_positionX == autre.getPositionX() && _positionY == autre.getPositionY());
}

void Personnage::mettreAJourAnimation() {
    _etatAnimation = (_etatAnimation + 1) % 4;
    _apparence.selectionnerRectangle((_spriteX + _etatAnimation % 2) * TAILLE_CASE, (_spriteY + _orientation) * TAILLE_CASE, TAILLE_CASE, TAILLE_CASE);
}
