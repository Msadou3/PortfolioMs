#include <vector>

#include "Moteur.h"
#include "Image.h"
#include "Personnage.h"
#include "Dictionnaire.h"

using namespace std;

int main(int, char**){
    Dictionnaire dico("assets/dictionnaire.txt");
    dico.afficher();
    Tuile t1;
    bool oui = dico.recherche("Piece", t1) ;
    if (oui){
        cout << endl;
        cout << "Tuile trouvee: ";
        t1.afficher();
    }
    else {
        cout <<"Tuile inconnue";
    }

    Tuile t2;
    oui = dico.recherche("sfe", t2) ;
    if (oui){
        cout << endl;
        cout << "Tuile trouvee: ";
        t2.afficher();
    }
    else {
        cout <<"Tuile inconnue";
    }

    return 0;
}
