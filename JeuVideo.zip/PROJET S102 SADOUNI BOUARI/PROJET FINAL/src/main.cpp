#include <vector>

#include "Moteur.h"
#include "Image.h"
#include "Personnage.h"
#include "Dictionnaire.h"
#include "Niveau.h"

using namespace std;

int main(int, char**) // Version spéciale du main, ne pas modifier
{
    // Initialisation du jeu
    Moteur moteur("Mon super jeu vidéo");

    // Chargement des images et initialisation des personnages
    Image fondEcran;
    try {
        fondEcran = Image(moteur, "assets/fond.png");
    } catch (invalid_argument &e) {
        cerr << "ERR : image introuvable" << endl;
    }

    Image coffreFerme(moteur, "assets/coffre_ferme.png");
    Image coffreOuvertImage(moteur, "assets/coffre_ouvert.png");
    bool coffreEstOuvert = false;

    Image tilesheetPersonnages(moteur, "assets/personnages.png");
    Personnage personnagePrincipal(tilesheetPersonnages, TAILLE_CASE, TAILLE_CASE * 2, 4, 0, BAS);
    Personnage garde1(tilesheetPersonnages, 5 * TAILLE_CASE, TAILLE_CASE, 1, 4, HAUT);
    Personnage garde2(tilesheetPersonnages, TAILLE_CASE, 5 * TAILLE_CASE, 10, 0, DROIT);

    Image tilesheetObjets(moteur, "assets/objets.png");
    Dictionnaire dictionnaire("assets/dictionnaire.txt");

    Niveau premierNiveau(tilesheetObjets, "assets/niveau1.txt", dictionnaire);

    Image imageGameOver(moteur, "assets/gameover.png");
    Image imageBravo(moteur, "assets/bravo.png");

    bool jeuTermine = false;
    bool herosMort = false;
    bool niveauReussi = false;

    // Boucle de jeu
    while (!jeuTermine) {
        // I. Gestion des événements
        Evenement evenement = moteur.evenementRecu();
        while (evenement != AUCUN) {
            switch (evenement) {
                // ESPACE_APPUYE = Change l'apparence du personnage
                case ESPACE_APPUYE:
                    personnagePrincipal.changerApparence();
                    break;

                // Déplacements du personnage principal
                case DROITE_APPUYE:
                    personnagePrincipal.seDeplacerDroite(premierNiveau);
                    break;
                case GAUCHE_APPUYE:
                    personnagePrincipal.seDeplacerGauche(premierNiveau);
                    break;
                case BAS_APPUYE:
                    personnagePrincipal.seDeplacerBas(premierNiveau);
                    break;
                case HAUT_APPUYE:
                    personnagePrincipal.seDeplacerHaut(premierNiveau);
                    break;

                // QUITTER = croix de la fenêtre ou Échap
                case QUITTER_APPUYE:
                    jeuTermine = true;
                    break;

                default:
                    break;
            }

            evenement = moteur.evenementRecu();
        }

        // II. Mise à jour de l'état du jeu
        if (moteur.animationsAmettreAjour()) {
            garde1.seDeplacerAleatoirement(premierNiveau);
            garde1.mettreAJourAnimation();
            garde2.seDeplacerAleatoirement(premierNiveau);
            garde2.mettreAJourAnimation();
            personnagePrincipal.mettreAJourAnimation();
        }

        herosMort = personnagePrincipal.estEnCollisionAvec(garde1) || personnagePrincipal.estEnCollisionAvec(garde2);
        niveauReussi = premierNiveau.getPieces() == 0;
        if (herosMort || niveauReussi) {
            jeuTermine = true;
        }

        // III. Génération de l'image à afficher
        moteur.initialiserRendu(); // Efface ce qui avait été affiché précédemment et réinitialise en écran noir

        // Affichage des éléments
        premierNiveau.dessiner();

        personnagePrincipal.afficher();
        garde1.afficher();
        garde2.afficher();

        // Affichage d'écran de fin
        if (herosMort) {
            imageGameOver.dessiner(2 * TAILLE_CASE, 3 * TAILLE_CASE);
        }
        if (niveauReussi) {
            imageBravo.dessiner(2 * TAILLE_CASE, 3 * TAILLE_CASE);
        }

        moteur.finaliserRendu();
    }

    // Pause de 4 secondes avant de quitter si jeu terminé
    if (herosMort || niveauReussi) {
        moteur.attendre(4);
    }

    return 0;
}
