#include "Tuile.h"


Tuile::Tuile(){
    _nom = "pas trouve";
    _posX = 0;
    _posY = 0;
    _propriete = "pas trouve";
}

Tuile::Tuile(const string& nom, int x, int y, const string& propriete){
    _nom = nom;
    _posX = x;
    _posY = y;
    _propriete = propriete;
}


void Tuile::afficher()const{
    cout << _nom << ": x=" << _posX << ", y=" << _posY << ", objet "<< _propriete << endl;
}

