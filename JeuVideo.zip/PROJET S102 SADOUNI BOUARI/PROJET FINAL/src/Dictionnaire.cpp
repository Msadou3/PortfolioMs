#include "Dictionnaire.h"
#include <fstream>




Dictionnaire::Dictionnaire(const string& nomFic){

    ifstream entree;

    try {
        entree.open(nomFic);
        if(!(entree.is_open())) throw(nomFic);
        int nbTuile;
        if (!entree.eof())
            entree >> nbTuile;
        for (int i = 0; i < nbTuile && !entree.eof(); i++) {
            string nom;
            int x;
            int y;
            string propriete;

            entree >> nom;
            entree >> x;
            entree >> y;
            entree >> propriete;
            _lesTuiles.push_back(Tuile(nom, x, y, propriete));
        }
        entree.close();
    } catch (const string & s) {
        cerr<< "pb ouverture du fichier : " << s;
    }
}


void Dictionnaire::afficher()const {
    for(int i=0; i<_lesTuiles.size(); i++){
        _lesTuiles[i].afficher();
    }
}

bool Dictionnaire::recherche(const string& val, Tuile& R){  // Recherche dichotomique car dictionnaire est deja tri� (ordre alphabetique)

    int milieu;
    int fin = _lesTuiles.size()-1;
    int debut = 0;
    bool trouve = false;

    while (!trouve && debut <= fin){
        milieu = (debut+fin)/2;
        if (val == _lesTuiles[milieu].getNom()){
            trouve = true;
            R = _lesTuiles[milieu];
        }
        if (!trouve){
            if (_lesTuiles[milieu].getNom() > val){
                fin = milieu-1;
            }
            else {
                debut = milieu +1;
            }
        }

    }

    return (trouve);
}



